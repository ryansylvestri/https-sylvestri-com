# The Complete Digital Domination Playbook
## A Reusable Framework for SEO, SMO & Brand Overhaul — Any Person, Any Brand, Any Industry

---

> **What this is:** A step-by-step instruction set to replicate the full digital branding, SEO, and SMO overhaul that was executed for Ryan Sylvestri (RE/MAX Town & Country). This playbook is industry-agnostic — it works for real estate agents, lawyers, doctors, contractors, restaurants, coaches, consultants, or any local/personal brand. Swap out the variables, follow the phases, and you'll get the same comprehensive output.

---

## HOW TO USE THIS PLAYBOOK

1. Fill in the **Variable Sheet** (Section 1) for your new subject
2. Feed the **Master Prompts** (Section 2) to an AI assistant, substituting your variables
3. Follow the **Phase Sequence** (Section 3) in order — each phase builds on the last
4. Use the **Platform Checklists** (Section 4) as your QA gate
5. Refer to the **Content Frameworks** (Section 5) for ongoing production
6. Track progress with the **Scoring Rubric** (Section 6)

---

## SECTION 1: Variable Sheet

Fill this out before starting. Every prompt in this playbook references these variables.

```
============================================================
SUBJECT INFORMATION
============================================================
Full Name:              [e.g., Ryan Sylvestri]
Professional Title:     [e.g., Licensed Associate Real Estate Broker]
Company/Brokerage:      [e.g., RE/MAX Town & Country]
Office Address:         [e.g., 584 U.S. Route 9, Fishkill, NY 12524]
Phone:                  [e.g., 845-867-2646]
Email:                  [e.g., ryan@thesylvestriteam.com]
License/Credential #:   [e.g., #10301220700]
Team Name (if any):     [e.g., The Sylvestri Team]
Years Experience:       [e.g., 12+]
Transaction Count:      [e.g., 54+]
Designations/Certs:     [e.g., ABR, PSA]

============================================================
INDUSTRY & SPECIALTIES
============================================================
Industry:               [e.g., Real Estate]
Primary Specialties:    [e.g., Residential, Commercial, Luxury, Foreclosure/REO]
Secondary Specialties:  [e.g., Investment, Relocation, Property Management]
Unique Differentiator:  [e.g., Tech background + property preservation/BPO experience]

============================================================
GEOGRAPHY
============================================================
Primary Market:         [e.g., Fishkill, NY]
Secondary Markets:      [e.g., Newburgh, Beacon, Wappingers Falls, Poughkeepsie]
Region/County:          [e.g., Hudson Valley / Dutchess County / Orange County]
Service Area Radius:    [e.g., 30 miles / Dutchess, Orange, Putnam counties]
Zip Codes Served:       [list all]

============================================================
TARGET KEYWORDS (fill as you research)
============================================================
Brand Keywords:         [e.g., Ryan Sylvestri, The Sylvestri Team]
Primary Service KWs:    [e.g., real estate agent Fishkill NY, realtor Hudson Valley]
Specialty KWs:          [e.g., foreclosure specialist, luxury homes Hudson Valley]
Location KWs:           [e.g., homes for sale Newburgh NY, Beacon NY real estate]
Long-tail KWs:          [e.g., moving from NYC to Hudson Valley, best schools Dutchess County]

============================================================
EXISTING DIGITAL PRESENCE (list all known URLs)
============================================================
Personal Website:       [URL]
Company Profile:        [URL]
Zillow:                 [URL]
Realtor.com:            [URL]
Google Business:        [claimed? Y/N]
Facebook:               [URL(s)]
Instagram:              [handle]
TikTok:                 [handle]
LinkedIn:               [URL]
Twitter/X:              [handle]
YouTube:                [URL]
Yelp:                   [URL]
Industry-Specific:      [e.g., Homes.com, Avvo, Healthgrades, Houzz]

============================================================
COMPETITORS (research these during audit)
============================================================
Competitor 1:           [name, brokerage, why they rank]
Competitor 2:           [name, brokerage, why they rank]
Competitor 3:           [name, brokerage, why they rank]
Top Ranking Site:       [what ranks #1 for primary keyword?]
============================================================
```

---

## SECTION 2: Master Prompts

These are the exact prompts to use, with `[VARIABLES]` you replace from the Variable Sheet. Feed them to an AI assistant (Perplexity Computer, Claude, ChatGPT, etc.) in sequence.

### PROMPT 1: The Comprehensive Audit

```
Redefine [FULL NAME], [PROFESSIONAL TITLE], [COMPANY] — all the branding, 
social media, public-facing pages, websites. Do a complete audit and overhaul 
for [FULL NAME]. I'm talking full-blown SEO and SMO.

Get [FULL NAME] to the top of every search engine for: [LIST ALL TARGET 
KEYWORDS — primary service, specialties, location, long-tail].

Here's what I know:
- Name: [FULL NAME]
- Title: [PROFESSIONAL TITLE]
- Company: [COMPANY]
- Location: [OFFICE ADDRESS]
- Phone: [PHONE]
- Experience: [YEARS] years, [TRANSACTION COUNT] [transactions/clients/cases]
- Specialties: [LIST ALL]
- Service areas: [LIST ALL]
- Known profiles: [LIST ALL KNOWN URLs]

Audit EVERY platform. Grade each one. Identify every critical issue. 
Research who's beating them in search results and why. Give me a full 
keyword strategy, content plan, and actionable roadmap.
```

### PROMPT 2: The Full Build

```
Build it all and build fixes to get [FULL NAME] an A+ rating all around. 
Specifically:

1. Build a full professional website with:
   - Homepage, About, Services/Areas, Resources (buyer/seller/client), 
     Testimonials, Blog, Contact
   - Full SEO: title tags, meta descriptions, schema markup, internal links
   - Mobile responsive, fast loading, accessible
   
2. Write optimized bios for EVERY platform found in the audit — each one 
   unique, tailored to that platform's audience and format

3. Build a review/testimonial request email campaign (3-email sequence + 
   SMS templates)

4. Create a complete Google Business Profile optimization guide with 
   step-by-step instructions, pre-written Q&As, and posting calendar

5. Write [NUMBER] neighborhood/area/service guide pages (1,200-1,500 words 
   each) with real data

6. Write 4 launch blog posts with current data and full SEO metadata

7. Create schema markup code (JSON-LD) ready to deploy

8. Build a 30-day social media content calendar with fully written captions
```

### PROMPT 3: The Archive Package

```
Please prep a complete downloadable package archive zip file with all of the 
assets and everything, including a summary of how we got to this point, any 
conversation and great prompts that should be saved. Think outside the box 
and create an additional markdown file of a comprehensive set of instructions 
that I can use to get back here using a different person or a different brand 
or a different entity.
```

---

## SECTION 3: Phase Sequence

### Phase 1: Discovery & Audit (1-2 hours)

**Goal:** Map the entire digital landscape, identify every gap, and understand the competitive environment.

#### Step 1.1 — Search for the subject
Run these searches and document everything found:
- `"[FULL NAME]" [INDUSTRY] [CITY]`
- `[FULL NAME] [COMPANY]`
- `[FULL NAME] [PLATFORM]` (for each: Zillow, LinkedIn, Instagram, Facebook, Yelp, etc.)
- `[FULL NAME] reviews`
- `site:[KNOWN WEBSITE]`

#### Step 1.2 — Audit each profile
For every profile found, evaluate:
- **Completeness:** Are all fields filled out? Bio, photo, contact info, specialties?
- **Keyword optimization:** Does the bio contain target keywords naturally?
- **NAP consistency:** Is Name, Address, Phone identical across all platforms?
- **Review presence:** How many reviews? What rating? Recent?
- **Content freshness:** When was the last post/update?
- **Link integrity:** Do links work? Is there a link in bio on social?
- **Visual branding:** Professional photo? Consistent across platforms?

#### Step 1.3 — Competitive analysis
- Search `best [INDUSTRY PROFESSIONAL] in [CITY]` and note who ranks
- Search `top [INDUSTRY] [CITY] [YEAR]` on ranking sites
- Identify what competitors do better (more reviews, better content, schema markup, etc.)
- Note if any competitor shares the same company/office

#### Step 1.4 — Grade each platform (A-F)
| Grade | Criteria |
|-------|----------|
| A | Fully optimized, keyword-rich, 20+ reviews, regular content, schema present |
| B | Good but missing some elements — reviews, blog, or advanced SEO |
| C | Basic presence, generic bio, minimal engagement, no optimization |
| D | Barely present, wrong info, outdated, or major issues |
| F | Non-existent, dead account, or actively harmful |

#### Step 1.5 — Deliver the audit
Create a comprehensive report including:
- Executive summary with the biggest gaps
- Platform-by-platform scorecard
- Critical issues list (numbered, prioritized)
- Competitive analysis
- Full keyword strategy with estimated search volumes
- Content plan (blog topics, neighborhood/service pages)
- 90-day action plan with week-by-week priorities

---

### Phase 2: Foundation Builds (2-4 hours)

**Goal:** Build everything the subject needs to go from current state to A+ across all platforms.

#### Step 2.1 — Website
Build a multi-page, SEO-optimized website:

**Must-have pages:**
- Home (hero, stats, services overview, testimonials, CTA)
- About (keyword-rich bio, credentials, differentiators)
- Services / Areas Served (hub with sub-pages)
- Resources / Guides (buyer/seller/client education)
- Testimonials / Reviews
- Blog (even if starting with 0 posts — the page must exist)
- Contact (form, map, phone, email, social links)

**Must-have SEO elements (every page):**
- Unique `<title>` tag under 60 characters
- Unique `<meta name="description">` under 160 characters
- Open Graph tags (`og:title`, `og:description`, `og:image`)
- Canonical URL (`<link rel="canonical">`)
- Single H1 tag with primary keyword
- Hierarchical H2/H3 structure
- Internal links to 3+ other pages
- Image alt text on every image
- JSON-LD schema markup
- Mobile responsive
- Fast loading (<3 seconds)
- SSL (HTTPS)
- XML sitemap
- robots.txt

#### Step 2.2 — Profile copy
Write unique, optimized bios for every platform. Each bio must:
- Be tailored to that platform's character limit and audience
- Include target keywords naturally
- Mention geographic service areas
- Include social proof (years experience, transaction count, review rating)
- End with a CTA (phone number, "contact me")
- Be DIFFERENT from every other platform's bio

**Platform-specific considerations:**
| Platform | Max Length | Audience | Tone |
|----------|-----------|----------|------|
| LinkedIn | 2,600 chars (About) | Professional/corporate | Authoritative, data-driven |
| Instagram | 150 chars | Casual consumers | Punchy, emoji-friendly |
| TikTok | 80 chars | Young/casual | Ultra-short, personality |
| Facebook | 255 chars (short desc) | General public | Warm, community-focused |
| Google Business | 750 chars | Local searchers | Keyword-dense, service-focused |
| Zillow/Realtor.com | 200-250 words | Active buyers/sellers | Expert, trust-building |
| Yelp | No limit | Local consumers | Service-focused, welcoming |

#### Step 2.3 — Review campaign
Build a 3-email sequence + SMS templates:
- **Email 1 (Day 7 post-close):** Warm, personal ask with links to all review platforms
- **Email 2 (Day 14):** Shorter follow-up, Google-first
- **Email 3 (Day 21):** Brief, gracious final nudge
- **SMS x3:** Under 160 chars each, different angles
- **Response templates:** 5 positive, 2 negative
- **Process document:** When to ask, which platform first, how to track

#### Step 2.4 — Google Business Profile
Create step-by-step guide covering:
- Claim & verify instructions
- Exact text for every field
- All service area zip codes
- Keyword-optimized description
- Services list with descriptions
- 15 pre-written Q&As
- 4-week posting calendar
- Review strategy with velocity targets

#### Step 2.5 — Content library
Write all content needed for immediate deployment:
- **Area/service guide pages** (10+ at 1,200-1,500 words each)
- **Blog posts** (4 for launch month, 1,000-1,500 words each)
- **Schema markup code** (JSON-LD, all applicable types)
- **30-day social media calendar** (full captions, hashtags, posting times)

---

### Phase 3: Deploy & Launch (1-2 hours)

**Goal:** Push everything live and start the optimization engine.

#### Deployment checklist:
- [ ] Website deployed to real domain (or S3 staging)
- [ ] Google Analytics 4 installed
- [ ] Google Search Console verified + sitemap submitted
- [ ] Google Business Profile claimed and verified
- [ ] All platform bios updated (Zillow, LinkedIn, Instagram, etc.)
- [ ] Instagram link in bio added
- [ ] Facebook pages consolidated
- [ ] NAP data consistent across all platforms
- [ ] Review request campaign sent to past clients
- [ ] First blog posts published
- [ ] Social media calendar scheduling started
- [ ] Schema markup validated (Google Rich Results Test)

---

### Phase 4: Ongoing Optimization (Monthly)

| Task | Frequency | Time |
|------|-----------|------|
| Blog posts (4/month) | Weekly | 2-3 hrs/month |
| Social media posts | Daily (5-7x/week) | 30 min/day |
| Google Business Profile posts | Weekly | 15 min/week |
| Review requests to new clients | After every closing | 5 min each |
| Review responses | Within 24 hours | 5 min each |
| Keyword ranking check | Monthly | 30 min |
| Content refresh (update old posts) | Quarterly | 2-3 hrs |
| Backlink outreach | Monthly | 1-2 hrs |
| Competitive monitoring | Monthly | 30 min |
| Platform profile updates | Quarterly | 1 hr |

---

## SECTION 4: Platform Checklists (A+ Criteria)

Use these as QA gates. Every box must be checked for an A+ rating.

### Website
- [ ] Custom domain with SSL
- [ ] Mobile-responsive (looks great at 375px)
- [ ] Page load under 3 seconds
- [ ] Unique title tags on every page (<60 chars, with keyword)
- [ ] Unique meta descriptions on every page (<160 chars)
- [ ] H1 tag with primary keyword on every page
- [ ] Schema markup (LocalBusiness + Person + FAQ + Service)
- [ ] XML sitemap submitted to Search Console
- [ ] Google Analytics installed
- [ ] Blog with 4+ published posts
- [ ] 10+ area/service pages
- [ ] Testimonials page with schema
- [ ] Contact form working
- [ ] Click-to-call on all phone numbers
- [ ] Social media links in footer
- [ ] Professional photos (not stock)
- [ ] Internal linking between all pages

### Google Business Profile
- [ ] Claimed and verified
- [ ] Correct business name
- [ ] Primary + secondary categories set
- [ ] Address, phone, website correct
- [ ] All service areas added (zip codes)
- [ ] Business description (keyword-optimized, 750 chars)
- [ ] 15+ services listed
- [ ] 20+ photos uploaded
- [ ] 10+ Q&As posted
- [ ] Posting weekly
- [ ] 20+ reviews (with responses to all)

### Zillow / Industry Portal
- [ ] Profile claimed and completed
- [ ] Keyword-rich bio (unique to platform)
- [ ] Professional photo
- [ ] All specialties selected
- [ ] 15+ reviews
- [ ] Video introduction uploaded
- [ ] Website link added
- [ ] Social links added
- [ ] Transaction history visible
- [ ] Regular activity/updates

### LinkedIn
- [ ] Optimized headline (120 chars, keywords)
- [ ] Keyword-rich About section (2,000+ chars)
- [ ] Correct location
- [ ] Professional photo + banner
- [ ] Experience entries up to date
- [ ] 15+ skills added
- [ ] 5+ recommendations
- [ ] Featured section with content
- [ ] Posting 3x/week
- [ ] Engaged in relevant groups

### Instagram
- [ ] Keyword-optimized bio
- [ ] Link in bio (Linktree or website)
- [ ] Professional profile photo
- [ ] 5+ Highlight reels (curated categories)
- [ ] Reels-first content strategy
- [ ] 20-30 hashtags per post (rotating sets)
- [ ] Posting 5-7x/week
- [ ] Following:follower ratio under 1:1
- [ ] Engagement: 15 min/day in local hashtags
- [ ] Consistent visual brand

### Facebook
- [ ] ONE consolidated business page
- [ ] Complete business info
- [ ] Reviews/recommendations enabled
- [ ] Posting 5x/week
- [ ] Cover photo + profile photo consistent with brand
- [ ] Messenger response enabled
- [ ] Events/community engagement active

### TikTok
- [ ] Keyword bio with CTA
- [ ] Link in bio
- [ ] Posting 5-7x/week
- [ ] Engaging with comments within 2 hours
- [ ] Trending sound usage
- [ ] Cross-posting to Reels and YouTube Shorts

---

## SECTION 5: Content Frameworks

### Blog Post Framework
```
TITLE: [Primary Keyword] — [Value Proposition/Year]
META TITLE: [Primary Keyword] | [Brand Name] (under 60 chars)
META DESCRIPTION: [Compelling description with keyword and CTA] (under 160 chars)

H1: [Title with primary keyword]

INTRO (100-150 words):
- Hook (statistic, question, or bold statement)
- What the reader will learn
- Why this matters to them

H2: [Section 1 - Background/Context]
(200-300 words with data/citations)

H2: [Section 2 - Core Content]
(300-400 words, the meat of the article)

H2: [Section 3 - Practical Application]
(200-300 words, actionable advice)

H2: [Section 4 - Expert Take/Local Angle]
(150-200 words, position yourself as the authority)

H2: FAQ (4-6 questions with concise answers)
(Use FAQPage schema)

CTA:
"Contact [NAME] at [PHONE] or [EMAIL] to [action]. As a [TITLE] 
with [COMPANY], [NAME] brings [X] years of experience to help you 
[achieve goal]."

INTERNAL LINKS: [Link to 3+ related pages]
KEYWORDS TO INCLUDE: [3-5 related terms]
IMAGE ALT TEXT: [Descriptive, keyword-adjacent]
```

### Social Media Post Framework
```
HOOK (first line — must stop the scroll):
- Question: "Did you know...?"
- Statistic: "[X]% of homebuyers..."
- Bold claim: "This is the #1 mistake..."
- Pattern interrupt: "Stop scrolling if you..."

BODY (2-4 lines of value):
- One clear takeaway per post
- Specific, not generic
- Local references when possible

CTA (last line):
- "Save this for later"
- "Comment [emoji] if you agree"
- "DM me for a free consultation"
- "Link in bio for more"
- "Call me at [PHONE]"

HASHTAGS (20-30, tiered):
- 5 high-volume industry hashtags
- 10 medium-volume niche hashtags
- 5-10 local/geographic hashtags
- 2-3 branded hashtags
```

### Neighborhood/Area Page Framework
```
H1: Living in [AREA], [STATE]: Your Complete [YEAR] Guide

META TITLE: [AREA] [STATE] [INDUSTRY] | [Service] | [NAME], [TITLE]
META DESC: Explore [AREA], [STATE] [industry] with [NAME]. 
Find [services], insights & data. Call [PHONE] today.

1. Introduction (100 words) — What makes this area special
2. Overview & Location (150 words) — Geography, proximity
3. Market Snapshot (150 words) — Current data, trends
4. Sub-areas & Communities (150 words) — Different neighborhoods
5. Schools & Education (150 words) — Ratings, districts
6. Commute & Transportation (100 words) — Transit options
7. Lifestyle & Highlights (150 words) — Things to do
8. Why Move Here (100 words) — Bullet-point summary
9. CTA (50 words) — Contact [NAME] for expert help
10. Internal links to 2-3 other area guides
```

### Review Request Email Framework
```
SUBJECT: Quick favor, [FIRST NAME]?

Hi [FIRST NAME],

I hope you're loving your [home/service/result] in [AREA]! 
It's been [TIME] since we [completed transaction/worked together], 
and I wanted to check in.

If you had a positive experience working with me, would you consider 
leaving a quick review? It takes about 2 minutes and means the world 
to my business.

[LINK TO REVIEW PLATFORM]

Even just a sentence or two about your experience helps future 
[clients/homebuyers/customers] feel confident in their choice.

Thank you so much — I truly appreciate your support!

Best,
[NAME]
[TITLE] | [COMPANY]
[PHONE]
```

---

## SECTION 6: Scoring Rubric

Use this to measure progress quarterly. Target: all A's within 6 months.

| Category | F | D | C | B | A |
|----------|---|---|---|---|---|
| **Website SEO** | No site | Placeholder site | Basic site, no blog | Good site, some SEO | Full SEO, blog, schema, 10+ pages |
| **Google Business** | Not claimed | Claimed, bare | Some info, few reviews | Complete, 10+ reviews | Full, 20+ reviews, weekly posts |
| **Review Volume** | 0-2 reviews | 3-7 reviews | 8-15 reviews | 16-25 reviews | 25+ reviews across platforms |
| **Social Following** | <100 | 100-500 | 500-2,000 | 2,000-5,000 | 5,000+ engaged followers |
| **Social Engagement** | <0.5% | 0.5-1% | 1-2% | 2-4% | 4%+ engagement rate |
| **Content Volume** | No content | <5 posts total | 5-15 blog posts | 15-30 blog posts | 30+ posts, weekly publishing |
| **Keyword Rankings** | Not ranking | Page 5+ | Page 2-3 | Page 1 (6-10) | Page 1 (top 3) |
| **NAP Consistency** | Major errors | 2+ inconsistencies | 1 inconsistency | Consistent, not verified | Verified, consistent everywhere |
| **Backlink Profile** | 0 local links | 1-3 links | 4-10 links | 10-20 links | 20+ quality local links |
| **Brand Consistency** | Fragmented | Mostly inconsistent | Somewhat consistent | Consistent with gaps | Unified across all platforms |

---

## SECTION 7: Industry-Specific Adaptations

### For Real Estate Agents
- **Key platforms:** Zillow, Realtor.com, Homes.com, Redfin
- **Content focus:** Neighborhood guides, market reports, buyer/seller education
- **Schema types:** RealEstateAgent, LocalBusiness, FAQPage
- **Review platforms:** Google, Zillow, Realtor.com, Homes.com, Facebook
- **Special keywords:** "homes for sale in [area]", "realtor near me", "[specialty] specialist"

### For Attorneys/Lawyers
- **Key platforms:** Avvo, Justia, FindLaw, Martindale-Hubbell
- **Content focus:** Practice area pages, case studies, legal guides, FAQ
- **Schema types:** Attorney, LegalService, LocalBusiness, FAQPage
- **Review platforms:** Google, Avvo, Yelp
- **Special keywords:** "[practice area] lawyer [city]", "attorney near me"

### For Doctors/Medical Professionals
- **Key platforms:** Healthgrades, Zocdoc, Vitals, WebMD
- **Content focus:** Condition guides, treatment pages, patient education
- **Schema types:** Physician, MedicalBusiness, MedicalClinic, FAQPage
- **Review platforms:** Google, Healthgrades, Zocdoc
- **Special keywords:** "[specialty] doctor [city]", "best [specialty] near me"

### For Contractors/Home Services
- **Key platforms:** HomeAdvisor, Angi, Houzz, Thumbtack
- **Content focus:** Service pages, project galleries, seasonal tips
- **Schema types:** HomeAndConstructionBusiness, LocalBusiness
- **Review platforms:** Google, HomeAdvisor, Yelp, Angi
- **Special keywords:** "[service] contractor [city]", "[service] near me"

### For Restaurants/Food Service
- **Key platforms:** Yelp, TripAdvisor, OpenTable, Google
- **Content focus:** Menu pages, chef/story page, events, seasonal specials
- **Schema types:** Restaurant, FoodEstablishment, Menu
- **Review platforms:** Google, Yelp, TripAdvisor
- **Special keywords:** "best [cuisine] restaurant [city]", "restaurants near me"

### For Coaches/Consultants
- **Key platforms:** LinkedIn (primary), personal website, YouTube
- **Content focus:** Thought leadership, case studies, methodology pages
- **Schema types:** ProfessionalService, Person, Course
- **Review platforms:** Google, LinkedIn Recommendations
- **Special keywords:** "[specialty] coach [city]", "[specialty] consultant"

---

## SECTION 8: Tools & Resources

### Free SEO Tools
- **Google Search Console** — Track rankings, indexing, technical issues
- **Google Analytics 4** — Traffic, user behavior, conversions
- **Google Business Profile** — Local SEO management
- **Google Keyword Planner** — Keyword research (need Google Ads account)
- **Google Rich Results Test** — Validate schema markup
- **PageSpeed Insights** — Site speed analysis
- **Bing Webmaster Tools** — Bing search data

### Free/Freemium Research Tools
- **Ubersuggest** — Keyword research, competitive analysis
- **AnswerThePublic** — Question-based keyword discovery
- **Google Trends** — Search trend analysis
- **AlsoAsked** — "People Also Ask" mining
- **ChatGPT / Claude / Perplexity** — Content ideation, writing, analysis

### Paid SEO Tools (optional, for scale)
- **Ahrefs** — Backlink analysis, keyword research, site audit
- **SEMrush** — All-in-one SEO platform
- **Moz** — Domain authority, local SEO tools
- **BrightLocal** — Local SEO and citation management
- **Screaming Frog** — Technical site audits

### Social Media Tools
- **Later / Buffer / Hootsuite** — Schedule posts across platforms
- **Canva** — Create graphics, carousels, video thumbnails
- **CapCut** — Video editing for Reels/TikTok
- **Linktree** — Link-in-bio tool for Instagram/TikTok

### Schema Markup Tools
- **Google Rich Results Test** — schema-validator
- **Schema.org** — Reference for all schema types
- **TechnicalSEO.com Schema Generator** — JSON-LD builder

---

## Final Notes

This playbook was originally built for a real estate broker but the framework is universal. The core principle: **most local professionals have the credentials to rank #1 but fail to translate those credentials into digital signals that search engines understand.** The gap between reality (great professional) and perception (invisible online) is what this system closes.

The sequence is always:
1. **Audit** — Find every gap and grade it
2. **Fix foundations** — NAP consistency, Google Business Profile, website
3. **Build authority** — Content, reviews, schema markup
4. **Amplify** — Social media, backlinks, ongoing publishing
5. **Measure** — Track rankings, reviews, traffic, leads

Do this for 6-12 months consistently and you'll dominate any local market.

---

*Originally created for Ryan Sylvestri, Associate Broker, RE/MAX Town & Country — March 2026*  
*Playbook framework by Perplexity Computer*
